# Project Guidelines: Indochine Luxe

## 1. Project Overview
"Indochine Luxe" is a high-end Vietnamese restaurant website representing a fusion of French Colonial elegance and Vietnamese tradition. The application is a Single Page Application (SPA) designed to offer a seamless, cinematic user experience.

**Key Aesthetics:**
*   **Modern Heritage:** A blend of old-world charm (colonial architecture, traditional patterns) and contemporary luxury.
*   **Atmosphere:** Moody, intimate, and dramatic. High contrast between deep backgrounds and illuminated focal points.
*   **Visual Language:**
    *   **Backgrounds:** Deep Charcoal and Noir (#1C1C1C).
    *   **Accents:** Antique Gold (#C5A059) used for borders, dividers, and refined typography.
    *   **Imagery:** Cinematic, dark-mood photography with dramatic lighting.

## 2. Tech Stack
*   **Framework:** React (Vite ecosystem)
*   **Styling:** Tailwind CSS v4.0 (using CSS variables for theme consistency)
*   **Routing:** `react-router-dom`
*   **State Management:** React Hooks (`useState`, `useEffect`)
*   **Icons:** `lucide-react`
*   **Layouts:** Flexbox, Grid, and `react-responsive-masonry` for galleries.

## 3. Design System & Tokens

### Colors
Defined as CSS variables in `/styles/globals.css`:
*   **Primary / Accent:** `var(--color-antique-gold)` -> `#C5A059`
*   **Background:** `var(--color-noir)` -> `#1C1C1C`
*   **Surface / Card:** `var(--color-charcoal)` -> `#2A2A2A`
*   **Text Main:** `var(--foreground)` -> `#FFFFFF` / `#F5F5F0`
*   **Text Muted:** `var(--muted-foreground)` -> `#A0A0A0`

### Typography
*   **Serif (Headings):** 'Playfair Display' -> `var(--font-serif)`
*   **Sans (Body/UI):** 'Inter' -> `var(--font-sans)`

### UI Patterns
*   **Buttons & CTAs:** Uppercase, `tracking-[0.2em]`, usually outlined or solid Gold. Hover effects typically invert colors or show borders.
*   **Dividers:** Gold lines (`h-[1px] bg-[#C5A059]`) used to separate content sections elegantly.
*   **Cards:** Dark backgrounds (`#2A2A2A`) with subtle gold borders or hover glow effects.
*   **Overlays:** Gradient overlays (`from-black/70`) used on hero images to ensure text readability.

## 4. Project Structure
```text
/
├── App.tsx                 # Main Router configuration
├── components/             # Feature components
│   ├── ui/                 # Reusable/Shadcn components
│   ├── Navigation.tsx      # Sticky header
│   ├── FullMenu.tsx        # Categorized menu list
│   ├── ReservationForm.tsx # Interactive booking form
│   └── ...
├── data/
│   └── content.ts          # Centralized data (text, menu items, config)
├── pages/                  # Page Views
│   ├── HomePage.tsx
│   ├── MenuPage.tsx
│   ├── GalleryPage.tsx
│   ├── ReservationsPage.tsx
│   └── ...
├── styles/
│   └── globals.css         # Global styles & Tailwind theme
└── guidelines/
    └── Guidelines.md       # Project documentation
```

## 5. Coding Standards

### Data Driven
*   **Central Source:** All static content (headlines, body text, menu items, contact info) MUST be stored in `/data/content.ts`.
*   **Iterative Rendering:** Components should map over data arrays from `content.ts` rather than hardcoding HTML.

### Styling
*   **Tailwind First:** Use utility classes for 95% of styling.
*   **Fonts:** Apply fonts using inline styles for CSS variables when specific font families are needed (e.g., `style={{ fontFamily: "var(--font-serif)" }}`).
*   **Spacing:** Use generous padding (`py-32`, `px-6`) to create a luxurious, uncluttered feel.

### Images
*   **Source:** Use high-quality, cinematic URLs (Unsplash).
*   **Styling:** `object-cover` is essential. Use `group-hover:scale` for subtle interactive movements.
*   **Fallbacks:** Always provide descriptive `alt` text using data from `content.ts`.

### Routing
*   **Internal:** Use `<Link to="/path">` from `react-router-dom`.
*   **External:** Use `<a href="..." target="_blank">` for social links or external services.

## 6. Extension Guidelines
*   **Adding Pages:**
    1.  Create a new file in `/pages/`.
    2.  Add the route to `/App.tsx`.
    3.  Update the `navigation` array in `/data/content.ts`.
*   **New Features:** Ensure any new UI component adheres to the Gold/Noir color palette and uses the standard Typography tokens. Avoid bright primary colors (blue, green, red) unless heavily desaturated/darkened to match the theme.
