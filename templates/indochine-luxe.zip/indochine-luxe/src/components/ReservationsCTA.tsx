import { Link } from "react-router-dom";
import { siteContent } from "../data/content";

export function ReservationsCTA() {
  return (
    <section
      id="reservations"
      className="py-32 px-6 bg-gradient-to-b from-[#1C1C1C] via-[#2A2A2A] to-[#1C1C1C] relative overflow-hidden"
    >
      {/* Background Accent */}
      <div className="absolute inset-0 flex items-center justify-center opacity-10">
        <svg
          width="600"
          height="600"
          viewBox="0 0 100 100"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M50 10 L60 40 L90 40 L66 58 L76 90 L50 70 L24 90 L34 58 L10 40 L40 40 Z"
            stroke="#C5A059"
            strokeWidth="0.2"
            fill="none"
          />
        </svg>
      </div>

      <div className="max-w-3xl mx-auto text-center relative z-10">
        <h2
          className="text-5xl md:text-6xl mb-8 tracking-wide"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          {siteContent.reservations.heading}
        </h2>
        <p className="text-xl text-gray-400 mb-6">
          {siteContent.reservations.subhead}
        </p>
        <p className="text-gray-500 mb-12 italic">
          {siteContent.reservations.note}
        </p>

        <div className="w-24 h-[1px] bg-[#C5A059] mx-auto mb-12" />

        <Link
          to="/reservations"
          className="inline-block bg-[#C5A059] text-[#1C1C1C] px-16 py-5 uppercase tracking-[0.2em] transition-all duration-500 hover:bg-transparent hover:border-2 hover:border-[#C5A059] hover:text-[#C5A059]"
        >
          {siteContent.reservations.cta.label}
        </Link>

        {/* Contact Info */}
        <div className="mt-16 pt-16 border-t border-[#C5A059]/20">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <p className="uppercase tracking-wider text-[#C5A059] mb-3">
                {siteContent.reservations.contact}
              </p>
              <p className="text-gray-300">{siteContent.contact.phone}</p>
              <p className="text-gray-300">{siteContent.contact.email}</p>
            </div>
            <div>
              <p className="uppercase tracking-wider text-[#C5A059] mb-3">
                {siteContent.reservations.location}
              </p>
              <p className="text-gray-300">{siteContent.footer.address.line1}</p>
              <p className="text-gray-300">{siteContent.footer.address.line2}</p>
              <p className="text-gray-300">{siteContent.footer.address.line3}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
