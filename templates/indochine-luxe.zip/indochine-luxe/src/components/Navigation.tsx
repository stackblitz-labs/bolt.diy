import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { siteContent } from "../data/content";

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? "bg-[#1C1C1C] shadow-lg" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          <Link
            to="/"
            className="tracking-[0.3em] uppercase text-white"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.branding.name}
          </Link>

          <div className="flex items-center gap-8">
            {siteContent.navigations.map((link) => {
              if (link.isCtaButton) {
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className="border-2 border-[#C5A059] text-[#C5A059] px-6 py-2 uppercase tracking-wider transition-all duration-300 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
                  >
                    {link.label}
                  </Link>
                );
              }
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className="uppercase tracking-wider text-white hover:text-[#C5A059] transition-colors duration-300"
                >
                  {link.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
