import { siteContent } from "../data/content";
import { Link } from "react-router-dom";

export function HeritageSection({ showCta = true }: { showCta?: boolean }) {
  return (
    <section id="heritage" className="py-32 px-6 bg-[#1C1C1C] relative overflow-hidden">
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M50 10 L60 40 L90 40 L66 58 L76 90 L50 70 L24 90 L34 58 L10 40 L40 40 Z' stroke='%23C5A059' stroke-width='0.5' fill='none'/%3E%3C/svg%3E")`,
          backgroundSize: "150px 150px",
        }}
      />

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <h2
            className="text-5xl md:text-6xl mb-6 tracking-wide"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.heritage.heading}
          </h2>
          <div className="w-24 h-[1px] bg-[#C5A059] mx-auto" />
        </div>

        {/* Story Content */}
        <div className="space-y-8">
          {siteContent.heritage.body.map((paragraph, index) => (
            <p
              key={index}
              className="text-lg text-gray-300 leading-relaxed first-letter:text-5xl first-letter:font-serif first-letter:text-[#C5A059] first-letter:mr-2 first-letter:float-left first-letter:leading-none"
            >
              {paragraph}
            </p>
          ))}
        </div>

        {/* Decorative Quote */}
        <div className="mt-16 border-l-2 border-[#C5A059] pl-8 py-4">
          <p
            className="text-2xl text-[#C5A059] italic"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.heritage.quote.text}
          </p>
          <p className="text-gray-500 mt-4 tracking-widest uppercase">
            {siteContent.heritage.quote.author}
          </p>
        </div>

        {/* CTA */}
        {showCta && (
          <div className="text-center mt-16">
            <Link
              to={siteContent.heritage.cta.link}
              className="inline-block border border-[#C5A059] text-[#C5A059] px-12 py-4 uppercase tracking-[0.2em] transition-all duration-500 hover:bg-[#C5A059] hover:text-[#1C1C1C]"
            >
              {siteContent.heritage.cta.label}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}
