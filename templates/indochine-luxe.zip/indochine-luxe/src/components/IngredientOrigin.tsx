import { siteContent } from "../data/content";

export function IngredientOrigin() {
  return (
    <section className="py-32 px-6 bg-[#2A2A2A]">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-24">
          <h2
            className="text-5xl md:text-6xl mb-6 tracking-wide"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.ingredients.heading}
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {siteContent.ingredients.subhead}
          </p>
          <div className="w-24 h-[1px] bg-[#C5A059] mx-auto mt-8" />
        </div>

        {/* Ingredients Grid */}
        <div className="grid md:grid-cols-3 gap-12">
          {siteContent.ingredients.items.map(ingredient => (
            <div key={ingredient.name} className="group">
              {/* Image Container */}
              <div className="relative overflow-hidden mb-8">
                <img
                  src={ingredient.imageSrc}
                  alt={ingredient.imagePrompt}
                  className="w-full h-80 object-cover transition-transform duration-700 group-hover:scale-110"
                />
                {/* Vignette Effect */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                
                {/* Origin Badge */}
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="border border-[#C5A059] bg-[#1C1C1C]/80 backdrop-blur-sm px-4 py-2">
                    <p className="text-[#C5A059] tracking-widest uppercase">
                      {ingredient.origin}
                    </p>
                  </div>
                </div>
              </div>

              {/* Text Content */}
              <div className="space-y-4">
                <h3
                  className="text-2xl tracking-wide"
                  style={{ fontFamily: "var(--font-serif)" }}
                >
                  {ingredient.name}
                </h3>
                <p className="text-gray-400 leading-relaxed">
                  {ingredient.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
