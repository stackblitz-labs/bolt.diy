import { useState } from "react";
import { siteContent } from "../data/content";

export function ReservationForm() {
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    guests: "2",
    name: "",
    email: "",
    phone: "",
    requests: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1500);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  if (isSuccess) {
    return (
      <div className="bg-[#2A2A2A] p-12 text-center border border-[#C5A059]/30 max-w-2xl mx-auto animate-fade-in">
        <div className="w-16 h-16 bg-[#C5A059] rounded-full flex items-center justify-center mx-auto mb-6">
          <svg
            className="w-8 h-8 text-[#1C1C1C]"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M5 13l4 4L19 7"
            />
          </svg>
        </div>
        <h3
          className="text-3xl text-white mb-4"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          {siteContent.reservations.confirmation}
        </h3>
        <p className="text-gray-300 mb-8 leading-relaxed">
          {siteContent.thankyouMsg(formData.name, formData.date, formData.time)}
          <br />
          {siteContent.confirmationEmailMsg(formData.email)}
        </p>
        <button
          onClick={() => {
            setIsSuccess(false);
            setFormData({
              date: "",
              time: "",
              guests: "2",
              name: "",
              email: "",
              phone: "",
              requests: "",
            });
          }}
          className="text-[#C5A059] uppercase tracking-widest hover:text-white transition-colors"
        >
          {siteContent.reservations.makeAnother}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto bg-[#2A2A2A] p-8 md:p-12 border border-[#C5A059]/20">
      <h2
        className="text-3xl text-white mb-8 text-center tracking-wide"
        style={{ fontFamily: "var(--font-serif)" }}
      >
        {siteContent.reservations.tableRequest}
      </h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-[#C5A059] uppercase tracking-wider text-xs">
              {siteContent.reservations.date}
            </label>
            <input
              required
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[#C5A059] uppercase tracking-wider text-xs">
              {siteContent.reservations.time}
            </label>
            <select
              required
              name="time"
              value={formData.time}
              onChange={handleChange}
              className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors appearance-none"
            >
              {siteContent.reservations.reservationTimes.map((time) => (
                <option key={time.value} value={time.value}>
                  {time.label}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-[#C5A059] uppercase tracking-wider text-xs">
              {siteContent.reservations.guests}
            </label>
            <select
              required
              name="guests"
              value={formData.guests}
              onChange={handleChange}
              className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors appearance-none"
            >
              {siteContent.reservations.numberOfGuests.map((num) => (
                <option key={num} value={num}>
                  {num} {siteContent.reservations.guests}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-[#C5A059] uppercase tracking-wider text-xs">
              {siteContent.common.name}
            </label>
            <input
              required
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder={siteContent.common.fullName}
              className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[#C5A059] uppercase tracking-wider text-xs">
              {siteContent.common.phoneNumber}
            </label>
            <input
              required
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder={siteContent.contact.phone}
              className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[#C5A059] uppercase tracking-wider text-xs">
            {siteContent.common.email}
          </label>
          <input
            required
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder={siteContent.contact.email}
            className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors"
          />
        </div>

        <div className="space-y-2">
          <label className="text-[#C5A059] uppercase tracking-wider text-xs">
            {siteContent.reservations.specialRequests}
          </label>
          <textarea
            name="requests"
            value={formData.requests}
            onChange={handleChange}
            placeholder={siteContent.reservations.specialRequestsPlaceholder}
            rows={4}
            className="w-full bg-[#1C1C1C] border border-[#444] text-white p-4 focus:border-[#C5A059] outline-none transition-colors resize-none"
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-[#C5A059] text-[#1C1C1C] py-4 uppercase tracking-[0.2em] font-semibold hover:bg-white transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? siteContent.reservations.processing : siteContent.reservations.confirmButton}
        </button>
      </form>
    </div>
  );
}
