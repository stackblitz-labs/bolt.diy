import { siteContent } from "../data/content";

export function FullMenu() {
  return (
    <section className="py-20 px-6 bg-[#1C1C1C]">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-20">
          <h1
            className="text-5xl md:text-7xl mb-6 text-white tracking-wider"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            Our Menu
          </h1>
          <p className="text-xl text-[#C5A059] italic">
            A curated journey of flavor
          </p>
        </div>

        <div className="space-y-24">
          {siteContent.fullMenu.map((category) => (
            <div key={category.category}>
              <h2
                className="text-4xl text-[#C5A059] mb-12 text-center tracking-widest uppercase border-b border-[#C5A059]/20 pb-6"
                style={{ fontFamily: "var(--font-serif)" }}
              >
                {category.category}
              </h2>
              
              <div className="grid gap-12">
                {category.items.map((item) => (
                  <div key={item.name} className="group">
                    <div className="flex items-baseline justify-between mb-2">
                      <h3 className="text-2xl text-white group-hover:text-[#C5A059] transition-colors duration-300" style={{ fontFamily: "var(--font-serif)" }}>
                        {item.name}
                      </h3>
                      <div className="flex-1 mx-6 border-b border-[#333] border-dashed opacity-50 relative top-[-6px]" />
                      <span className="text-xl text-[#C5A059] font-serif">
                        ${item.price}
                      </span>
                    </div>
                    <p className="text-gray-400 italic">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-24 pt-12 border-t border-[#C5A059]/20">
          <p className="text-gray-500 italic text-sm">
            Please inform your server of any allergies or dietary requirements.
            <br />
            A 20% service charge will be added to parties of 6 or more.
          </p>
        </div>
      </div>
    </section>
  );
}
