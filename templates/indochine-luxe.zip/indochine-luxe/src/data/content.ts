import { siteAssets, siteComplexContent } from "./assets";

export const siteText = {
  seo: {
    title: "Indochine Luxe | Contemporary Vietnamese Cuisine",
    description: "Experience the soul of Saigon through elevated Vietnamese cuisine. Traditional family recipes meet modern culinary artistry in an intimate, heritage-inspired setting.",
  },
  branding: {
    name: "Indochine Luxe",
    slogan: "A culinary journey through the soul of Saigon, where heritage meets artistry."
  },
  common: {
    connect: "Connect",
    contact: "Contact",
    dressCode: "Dress Code",
    dressCodeDescription: "Smart elegant. We politely ask that gentlemen wear long trousers and covered shoes.",
    email: "Email",
    hours: "Hours",
    location: "Location",
    name: "Name",
    fullName: "Full Name",
    phoneNumber: "Phone Number"
  },
  navigations: [
    { label: "Home", path: "/" },
    { label: "Menu", path: "/menu" },
    { label: "Heritage", path: "/story" },
    { label: "Gallery", path: "/gallery" },
    { label: "Reservations", path: "/reservations", isCtaButton: true },
  ],
  hero: {
    eyebrow: "Contemporary Vietnamese Cuisine",
    headline: "The Soul of Saigon",
    subhead: "A culinary journey through the flavors of Vietnam, where tradition meets artistry.",
    cta: {
      label: "Discover",
      link: "/menu",
    },
    backgroundImage: {
      alt: "Vietnamese cuisine",
      src: "https://images.unsplash.com/photo-1757305932045-5310244e213f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjBkYXJrJTIwdmlldG5hbWVzZSUyMHBobyUyMHdhZ3l1JTIwYmVlZiUyMGx1eHVyeSUyMGdvbGQlMjBhY2NlbnRzJTIwaGlnaCUyMGVuZHxlbnwxfHx8fDE3NjQ0ODg2OTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    imagePrompt: "Cinematic dark shot of a ceramic bowl of Pho with Wagyu beef slices, steam rising, dramatic side lighting, dark background with subtle gold geometric patterns",
  },
  menuHighlights: {
    heading: "Chef's Signatures",
    subhead: "Each dish tells a story of heritage, crafted with reverence and refined through generations.",
    items: [
      {
        name: "Wagyu Phở Bò",
        price: "48",
        description: "Australian Wagyu, 24-hour bone broth, charred onion, star anise. The essence of patience.",
        imagePrompt: "Dramatic overhead shot of wagyu pho in black ceramic bowl, steam rising, dark moody lighting",
        imageSrc: "https://images.unsplash.com/photo-1642517788054-57d0bc2d2e26?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YWd5dSUyMGJlZWYlMjBwaG8lMjBkYXJrJTIwbW9vZHklMjBmaW5lJTIwZGluaW5nfGVufDF8fHx8MTc2NDQ4ODY5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        name: "Truffle Bánh Cuốn",
        price: "32",
        description: "Hand-rolled rice sheets, black truffle, wood-ear mushroom, crispy shallots. Delicate umami.",
        imagePrompt: "Close-up of translucent banh cuon rolls with truffle shavings, dark plate, gold accent",
        imageSrc: "https://images.unsplash.com/photo-1692958211324-147c95a9878b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aWV0bmFtZXNlJTIwc3ByaW5nJTIwcm9sbHMlMjByaWNlJTIwcm9sbHMlMjBkYXJrJTIwZWxlZ2FudCUyMGZpbmUlMjBkaW5pbmclMjB0cnVmZmxlfGVufDF8fHx8MTc2NDQ4ODY5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      },
      {
        name: "Claypot Sea Bass Cá Kho Tộ",
        price: "42",
        description: "Caramelized wild sea bass, young coconut water, black pepper from Phú Quốc. Aromatic depth.",
        imagePrompt: "Side-lit clay pot with caramelized fish, steam, dramatic shadows, dark background",
        imageSrc: "https://images.unsplash.com/photo-1718395012128-a6d204223093?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJhbWVsaXplZCUyMGZpc2glMjBjbGF5cG90JTIwdmlldG5hbWVzZSUyMGRhcmslMjBtb29keSUyMGZvb2QlMjBwaG90b2dyYXBoeXxlbnwxfHx8fDE3NjQ0ODg2OTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        name: "Crispy Bánh Xèo",
        price: "28",
        description: "Turmeric crepe, tiger prawns, pork belly, mung beans. Texture elevated to art.",
        imagePrompt: "Golden crispy banh xeo on dark plate, herbs scattered, dramatic lighting from side",
        imageSrc: "https://images.unsplash.com/photo-1602572683088-609cef970fe5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5oJTIweGVvJTIwdmlldG5hbWVzZSUyMHBhbmNha2UlMjBjcmlzcHklMjBkYXJrJTIwbW9vZHklMjBlbGVnYW50fGVufDF8fHx8MTc2NDQ4ODY5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
    ],
    cta: {
      label: "View Full Menu",
      link: "/menu",
    },
  },
  fullMenu: [
    {
      category: "Starters",
      items: [
        { name: "Wagyu Beef Tartare", price: "28", description: "Hand-cut wagyu, quail egg, shrimp chips, roasted rice powder." },
        { name: "Imperial Spring Rolls", price: "24", description: "Crab meat, pork, glass noodles, wood ear mushroom, blistered skin." },
        { name: "Green Papaya Salad", price: "22", description: "Dried beef jerky, Thai basil, roasted peanuts, chili lime vinaigrette." },
        { name: "Hokkaido Scallop Carpaccio", price: "34", description: "Nuoc mam ginger dressing, pomelo sacks, micro cilantro." }
      ]
    },
    {
      category: "Mains",
      items: [
        { name: "Lemongrass Chili Chicken", price: "36", description: "Free-range chicken, fresh lemongrass, bird's eye chili, claypot reduction." },
        { name: "Shaking Beef (Bò Lúc Lắc)", price: "46", description: "Wagyu cubes, watercress, cherry tomatoes, kampot pepper lime sauce." },
        { name: "Tamarind Prawns", price: "42", description: "Tiger prawns, tamarind glaze, fried shallots, garlic butter baguette." },
        { name: "Roasted Duck Curry", price: "38", description: "Red curry, lychee, pineapple, Thai basil, coconut cream." }
      ]
    },
    {
      category: "Soups & Noodles",
      items: [
        { name: "Classic Phở Bò", price: "26", description: "Rare beef slices, brisket, beef balls, 18-hour broth." },
        { name: "Bun Cha Hanoi", price: "32", description: "Grilled pork belly, meatballs, vermicelli, fresh herbs, dipping sauce." },
        { name: "Spicy Beef Noodle (Bún Bò Huế)", price: "30", description: "Lemongrass beef broth, pork hock, beef shank, chili satay." }
      ]
    },
    {
      category: "Desserts",
      items: [
        { name: "Vietnamese Coffee Tiramisu", price: "18", description: "Robusta coffee soaked ladyfingers, condensed milk mascarpone." },
        { name: "Pandan Panna Cotta", price: "16", description: "Coconut cream, palm sugar syrup, toasted sesame." },
        { name: "Banana Cake", price: "16", description: "Warm banana cake, coconut sauce, toasted peanuts." }
      ]
    }
  ],
  ingredients: {
    heading: "Sourced with Intention",
    subhead: "Every ingredient honors its origin, traced from mountain to market.",
    items: [
      {
        name: "Star Anise",
        origin: "Lạng Sơn Province",
        description: "Harvested at peak aromatic intensity, sun-dried for seven days.",
        imagePrompt: "Star anise scattered on dark slate, dramatic top lighting, moody atmosphere",
        imageSrc: "https://images.unsplash.com/photo-1634114627043-9a2abf455494?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFyJTIwYW5pc2UlMjBzcGljZXMlMjBkYXJrJTIwYmFja2dyb3VuZCUyMG1hY3JvJTIwbW9vZHl8ZW58MXx8fHwxNzY0NDg4Njk5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        name: "Cassia Cinnamon",
        origin: "Yên Bái Highlands",
        description: "Hand-peeled bark from century-old trees. Sweet, earthy warmth.",
        imagePrompt: "Cinnamon sticks on dark wood surface, soft side lighting, rustic elegant",
        imageSrc: "https://images.unsplash.com/photo-1739895958716-b5dd01b92808?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5uYW1vbiUyMHN0aWNrcyUyMGRhcmslMjBtb29kJTIwZWxlZ2FudCUyMGxpZ2h0aW5nfGVufDF8fHx8MTc2NDQ4ODcwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        name: "Black Cardamom",
        origin: "Sapa Mountains",
        description: "Smoke-dried over pine wood. Deep, camphor-laced complexity.",
        imagePrompt: "Black cardamom pods on dark ceramic, dramatic shadows, moody lighting",
        imageSrc: "https://images.unsplash.com/photo-1543831113-c823c4a606b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibGFjayUyMGNhcmRhbW9tJTIwcG9kcyUyMHNwaWNlcyUyMGRhcmslMjBiYWNrZ3JvdW5kfGVufDF8fHx8MTc2NDQ4ODcwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
    ],
  },
  heritage: {
    heading: "From Our Roots",
    body: [
      "Our story begins in a narrow alley off Nguyễn Huệ Boulevard, where three generations perfected the art of phở in a kitchen no larger than a whisper. What started as a humble street cart in 1952 has evolved into a culinary philosophy: honor the past, elevate the present.",
      "Chef Minh Trần spent fifteen years apprenticing in Hanoi, Paris, and Tokyo before returning to Saigon with a singular mission—to translate the soul of Vietnamese street food into a language of modern gastronomy. Each recipe is a dialogue between memory and innovation, between the charcoal braziers of old Saigon and the precision of contemporary technique.",
      "We source our ingredients as our grandmothers did—directly from farmers we know by name, from regions where soil and tradition create irreplaceable flavor. This is not fusion. This is evolution.",
    ],
    quote: {
      text: "Honor the past, elevate the present.",
      author: "— Chef Minh Trần",
    },
    cta: {
      label: "Our Philosophy",
      link: "/story",
    },
  },
  gallery: {
    heading: "The Space",
    subhead: "An intimate sanctuary where French Colonial elegance meets Vietnamese craftsmanship.",
    images: [
      { 
        prompt: "Dark moody restaurant interior with velvet booth, brass lanterns, dark wood",
        alt: "Velvet booth seating with brass accents",
        src: "https://images.unsplash.com/photo-1672457674313-eea8b018c697?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBkYXJrJTIwcmVzdGF1cmFudCUyMGludGVyaW9yJTIwZ29sZCUyMHZlbHZldCUyMGFzaWFuJTIwbW9kZXJufGVufDF8fHx8MTc2NDQ4ODcwMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      { 
        prompt: "Close-up of rattan room divider screen in restaurant, dramatic lighting",
        alt: "Handwoven rattan privacy screens",
        src: "https://images.unsplash.com/photo-1760662503661-5f3781cd2a87?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwdmVsdmV0JTIwcmVzdGF1cmFudCUyMGJvb3RoJTIwbHV4dXJ5JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY0NDg4NzA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      { 
        prompt: "Hanging silk lanterns in dark restaurant, warm golden glow",
        alt: "Vietnamese silk lanterns",
        src: "https://images.unsplash.com/photo-1682603105358-c0fc9c238f1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMHJlc3RhdXJhbnQlMjBsYW50ZXJuJTIwZGFyayUyMG1vb2R5JTIwZ29sZHxlbnwxfHx8fDE3NjQ0ODg3MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      { 
        prompt: "Dark ceramic plates and brass chopsticks on dark table, luxury dining",
        alt: "Lacquerware table setting",
        src: "https://images.unsplash.com/photo-1574288361601-74b6d68ec626?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5lJTIwZGluaW5nJTIwdGFibGUlMjBzZXR0aW5nJTIwZGFyayUyMGNlcmFtaWMlMjBnb2xkJTIwY3V0bGVyeXxlbnwxfHx8fDE3NjQ0ODg3MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      { 
        prompt: "Restaurant bar with dark wood, brass details, bottles backlit",
        alt: "Heritage bar with Vietnamese spirits",
        src: "https://images.unsplash.com/photo-1724502317390-88e42644374a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjByZXN0YXVyYW50JTIwYmFyJTIwZGFyayUyMHdvb2QlMjBzaGVsdmVzJTIwYm90dGxlc3xlbnwxfHx8fDE3NjQ0ODg3MDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      { 
        prompt: "Arched doorway with dark walls and golden light, luxury restaurant",
        alt: "French Colonial architectural details",
        src: "https://images.unsplash.com/photo-1745549670488-6852ef218009?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwcHJpdmF0ZSUyMGRpbmluZyUyMHJvb20lMjBhc2lhbiUyMHNjcmVlbiUyMGRhcmt8ZW58MXx8fHwxNzY0NDg4NzA5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        prompt: "Chef plating a dish with tweezers, dark kitchen background, focused lighting",
        alt: "Culinary artistry in action",
        src: "https://images.unsplash.com/photo-1621494268492-d01b98eba7e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwcGxhdGluZyUyMGZvb2QlMjBkYXJrJTIwbW9vZHklMjBmaW5lJTIwZGluaW5nfGVufDF8fHx8MTc2NDQ4OTE2Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        prompt: "Cocktail with smoke bubble, dark moody bar setting, gold rim",
        alt: "Signature smoked cocktails",
        src: "https://images.unsplash.com/photo-1651410634315-56a535912396?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NrdGFpbCUyMHNtb2tlJTIwbW9vZHklMjBiYXIlMjBkYXJrJTIwbHV4dXJ5fGVufDF8fHx8MTc2NDQ4OTE2Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      },
      {
        prompt: "Outdoor terrace dining at night, string lights, tropical plants, dark sky",
        alt: "Al fresco dining terrace",
        src: "https://images.unsplash.com/photo-1757840354309-874ba896be68?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwdGVycmFjZSUyMG5pZ2h0JTIwZGFyayUyMHRyb3BpY2FsJTIwZWxlZ2FudHxlbnwxfHx8fDE3NjQ0ODkxNjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
      }
    ],
    page: {
      heading: "The Gallery",
      subhead: "Glimpses into our world, where every detail is a testament to heritage and luxury."
    },
    cta: {
      label: "View Gallery",
      link: "/gallery",
    },
  },
  reservations: {
    heading: "Reservations",
    subhead: "Secure your table for an unforgettable evening of culinary artistry.",
    note: "For private dining inquiries and groups larger than 6, please contact us directly.",
    confirmation: "Reservation confirmed.",
    confirmationEmailMsg: "A confirmation email has been sent to ",
    date: "Date",
    time: "Time",
    guests: "Guests",
    reservationTimes: [
      { label: "Select Time", value: "" },
      { label: "6:00 PM", value: "18:00" },
      { label: "6:30 PM", value: "18:30" },
      { label: "7:00 PM", value: "19:00" },
      { label: "7:30 PM", value: "19:30" },
      { label: "8:00 PM", value: "20:00" },
      { label: "8:30 PM", value: "20:30" },
      { label: "9:00 PM", value: "21:00" },
    ],
    selectTime: "Select Time",
    specialRequests: "Special Requests",
    specialRequestsPlaceholder: "Allergies, special occasions, etc.",
    makeAnother: "Make Another Reservation",
    numberOfGuests: [2, 3, 4, 5, 6, 7, 8],
    processing: "Processing...",
    confirmButton: "Confirm Reservation",
    tableRequest: "Table Request",
    thankYouMsg: "Thank you. We look forward to welcoming you on",
    cta: {
      label: "Book Now",
      link: "/reservations",
    },
  },
  footer: {
    address: {
      line1: "123 Đồng Khởi Street",
      line2: "District 1, Ho Chi Minh City",
      line3: "Vietnam",
    },
    hours: [
      { days: "Tuesday - Thursday", time: "6:00 PM - 10:30 PM" },
      { days: "Friday - Saturday", time: "6:00 PM - 11:30 PM" },
      { days: "Sunday - Monday", time: "Closed" },
    ]
  }
};

export const siteContent = { ...siteText, ...siteAssets, ...siteComplexContent };