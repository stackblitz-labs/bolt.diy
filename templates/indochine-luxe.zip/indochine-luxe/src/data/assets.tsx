import { JSX } from "react/jsx-runtime";

export const siteAssets = {
  contact: {
    phone: "+84 28 3829 5555",
    email: "reservations@indochineluxe.vn",
  },
  socials: [
    { platform: "Instagram", url: "https://instagram.com/indochineluxe" },
    { platform: "Facebook", url: "https://facebook.com/indochineluxe" },
  ],
}

export const siteComplexContent = {
  thankyouMsg: (name: string, date: string, time: string): JSX.Element => {
    return (
      <>
        Thank you, {name}. We look forward to welcoming you on 
        <span className="text-[#C5A059]"> {date} </span> at
        <span className="text-[#C5A059]"> {time}</span>.
      </>
    );
  },
  confirmationEmailMsg: (email: string): JSX.Element => {
    return (
      <>
        A confirmation email has been sent to {email}.
      </>
    );
  }
}