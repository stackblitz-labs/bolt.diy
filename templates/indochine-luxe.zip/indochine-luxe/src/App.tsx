import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navigation } from "./components/Navigation";
import { Footer } from "./components/Footer";
import { ScrollToTop } from "./components/ScrollToTop";
import { HomePage } from "./pages/HomePage";
import { MenuPage } from "./pages/MenuPage";
import { StoryPage } from "./pages/StoryPage";
import { GalleryPage } from "./pages/GalleryPage";
import { ReservationsPage } from "./pages/ReservationsPage";
import "./styles/globals.css";

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col justify-between">
        <Navigation />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/menu" element={<MenuPage />} />
          <Route path="/story" element={<StoryPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/reservations" element={<ReservationsPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}
