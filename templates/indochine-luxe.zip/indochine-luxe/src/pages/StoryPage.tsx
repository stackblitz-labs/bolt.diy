import { HeritageSection } from "../components/HeritageSection";
import { IngredientOrigin } from "../components/IngredientOrigin";

export function StoryPage() {
  return (
    <main className="pt-24 bg-[#1C1C1C] min-h-screen">
      <HeritageSection showCta={false} />
      <IngredientOrigin />
    </main>
  );
}
