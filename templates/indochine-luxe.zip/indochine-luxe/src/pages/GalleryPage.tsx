import Masonry from "react-responsive-masonry";
import { siteContent } from "../data/content";

const galleryImages = siteContent.gallery.images;

export function GalleryPage() {
  return (
    <main className="pt-32 bg-[#1C1C1C] min-h-screen">
       <div className="max-w-7xl mx-auto px-6 pb-32">
         <div className="text-center mb-24">
           <h1
             className="text-5xl md:text-7xl mb-6 text-white tracking-wider"
             style={{ fontFamily: "var(--font-serif)" }}
           >
             {siteContent.gallery.page.heading}
           </h1>
           <p className="text-xl text-[#C5A059] italic max-w-2xl mx-auto">
             {siteContent.gallery.page.subhead}
           </p>
         </div>

         <Masonry columnsCount={3} gutter="24px">
           {galleryImages.map((image, index) => (
             <div key={index} className="group relative overflow-hidden cursor-pointer mb-6">
               <img
                 src={image.src}
                 alt={image.alt}
                 className="w-full h-auto transition-all duration-1000 group-hover:scale-105 filter brightness-90 group-hover:brightness-100"
               />
               
               {/* Gold Frame on Hover */}
               <div className="absolute inset-0 border border-[#C5A059] scale-95 opacity-0 group-hover:opacity-100 group-hover:scale-100 transition-all duration-700 pointer-events-none" />
               
               {/* Caption */}
               <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 translate-y-4 group-hover:translate-y-0">
                 <p className="text-[#C5A059] italic font-serif text-lg">{image.alt}</p>
               </div>
             </div>
           ))}
         </Masonry>
       </div>
    </main>
  );
}
