import { ReservationForm } from "../components/ReservationForm";
import { siteContent } from "../data/content";

export function ReservationsPage() {
  return (
    <main className="pt-32 bg-[#1C1C1C] min-h-screen flex flex-col justify-center pb-24">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <h1
            className="text-5xl md:text-7xl mb-6 text-white tracking-wider"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            {siteContent.reservations.heading}
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            {siteContent.reservations.subhead}
          </p>
        </div>

        {/* Layout: Form and Info */}
        <div className="grid lg:grid-cols-12 gap-12 max-w-6xl mx-auto">
          {/* Form Section */}
          <div className="lg:col-span-8">
             <ReservationForm />
          </div>

          {/* Info Sidebar */}
          <div className="lg:col-span-4 space-y-12">
            {/* Contact */}
            <div className="bg-[#2A2A2A] p-8 border border-[#333]">
              <h3 className="text-xl text-[#C5A059] uppercase tracking-widest mb-6">
                {siteContent.common.contact}
              </h3>
              <div className="space-y-4 text-gray-300">
                <p>{siteContent.contact.phone}</p>
                <p>{siteContent.contact.email}</p>
                <p className="text-sm text-gray-500 mt-4">
                  {siteContent.reservations.note}
                </p>
              </div>
            </div>

            {/* Hours */}
            <div className="bg-[#2A2A2A] p-8 border border-[#333]">
              <h3 className="text-xl text-[#C5A059] uppercase tracking-widest mb-6">
                {siteContent.common.hours}
              </h3>
              <div className="space-y-4 text-gray-300">
                {siteContent.footer.hours.map((item) => (
                  <div key={item.days} className="flex justify-between text-sm border-b border-[#444] pb-2 last:border-0 last:pb-0">
                    <span>{item.days}</span>
                    <span className="text-white">{item.time}</span>
                  </div>
                ))}
              </div>
            </div>
            
             {/* Dress Code */}
             <div className="bg-[#2A2A2A] p-8 border border-[#333]">
              <h3 className="text-xl text-[#C5A059] uppercase tracking-widest mb-6">
                {siteContent.common.dressCode}
              </h3>
              <p className="text-gray-300 text-sm leading-relaxed">
                {siteContent.common.dressCodeDescription}
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
